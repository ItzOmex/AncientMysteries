const text =
"Experience next-generation AI tools for chatting, coding, image generation, automation and creativity.";

let i = 0;

function type(){

if(i<text.length){

document.getElementById("typing").innerHTML+=text.charAt(i);

i++;

setTimeout(type,30);

}

const menuBtn = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

menuBtn.addEventListener("click", () => {

    navLinks.classList.toggle("active");

    if(navLinks.classList.contains("active")){

        menuBtn.innerHTML = '<i class="fa-solid fa-xmark"></i>';

    }else{

        menuBtn.innerHTML = '<i class="fa-solid fa-bars"></i>';

    }

});

}

const generateBtn = document.getElementById("generateBtn");

const promptInput = document.getElementById("promptInput");

const aiOutput = document.getElementById("aiOutput");

generateBtn.addEventListener("click", () => {

const prompt = promptInput.value.trim();

if(prompt===""){

aiOutput.innerHTML="Please enter a prompt.";

return;

}

aiOutput.innerHTML="Thinking...";

setTimeout(()=>{

aiOutput.innerHTML=

`You asked:

"${prompt}"

This is a demo response from Omex AI.

In the final version, this section can connect to a real AI API like OpenAI or Gemini to generate intelligent answers.`;

},1200);

});

window.onload=()=>{

type();

const counters=document.querySelectorAll(".counter");

counters.forEach(counter=>{

const update=()=>{

const target=+counter.getAttribute("data-target");

const current=+counter.innerText;

const increment=target/100;

if(current<target){

counter.innerText=Math.ceil(current+increment);

setTimeout(update,20);

}else{

counter.innerText=target;

}

};

update();

});

};

const reveals=document.querySelectorAll(".reveal");

window.addEventListener("scroll",()=>{

reveals.forEach(section=>{

const top=section.getBoundingClientRect().top;

if(top<window.innerHeight-120){

section.classList.add("active");

}

});

});

const copyBtn = document.getElementById("copyBtn");

copyBtn.addEventListener("click", () => {

const code = document.getElementById("codeBox").innerText;

navigator.clipboard.writeText(code);

copyBtn.innerText = "Copied!";

setTimeout(() => {

copyBtn.innerText = "Copy Code";

}, 2000);

});

const tiltCards = document.querySelectorAll(".tilt-card");

tiltCards.forEach(card=>{

card.addEventListener("mousemove",(e)=>{

const rect = card.getBoundingClientRect();

const x = e.clientX - rect.left;

const y = e.clientY - rect.top;

const centerX = rect.width/2;

const centerY = rect.height/2;

const rotateX = -(y-centerY)/12;

const rotateY = (x-centerX)/12;

card.style.transform =
`perspective(1000px)
 rotateX(${rotateX}deg)
 rotateY(${rotateY}deg)
 scale(1.05)`;

});

card.addEventListener("mouseleave",()=>{

card.style.transform =
"perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)";

});

});

// FAQ

document.querySelectorAll(".faq-question").forEach(btn=>{

btn.onclick=function(){

const answer=this.nextElementSibling;

answer.style.display=

answer.style.display==="block"

? "none"

: "block";

};

});

// Back To Top

const topBtn = document.getElementById("topBtn");

if (topBtn) {

    window.addEventListener("scroll", function () {

        if (document.documentElement.scrollTop > 300) {
            topBtn.style.display = "block";
        } else {
            topBtn.style.display = "none";
        }

    });

    topBtn.addEventListener("click", function () {

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    });

}